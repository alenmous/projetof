﻿namespace PROJETO.views
{
    partial class Pessoa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbOBCliente = new System.Windows.Forms.Label();
            this.lbOBApelido = new System.Windows.Forms.Label();
            this.lbApelido = new System.Windows.Forms.Label();
            this.txtApelido = new System.Windows.Forms.TextBox();
            this.lbCliente = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblrg = new System.Windows.Forms.Label();
            this.lblCpf = new System.Windows.Forms.Label();
            this.lbRG = new System.Windows.Forms.Label();
            this.lbCpfOuCnpj = new System.Windows.Forms.Label();
            this.txtCPFouCNPJ = new System.Windows.Forms.TextBox();
            this.lbOBEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtCelular = new System.Windows.Forms.TextBox();
            this.lbCelular = new System.Windows.Forms.Label();
            this.lbTelefone = new System.Windows.Forms.Label();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.lbEmail = new System.Windows.Forms.Label();
            this.txtRG = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbOBCliente
            // 
            this.lbOBCliente.AutoSize = true;
            this.lbOBCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOBCliente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbOBCliente.Location = new System.Drawing.Point(24, 31);
            this.lbOBCliente.Name = "lbOBCliente";
            this.lbOBCliente.Size = new System.Drawing.Size(13, 17);
            this.lbOBCliente.TabIndex = 1605;
            this.lbOBCliente.Text = "*";
            // 
            // lbOBApelido
            // 
            this.lbOBApelido.AutoSize = true;
            this.lbOBApelido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOBApelido.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbOBApelido.Location = new System.Drawing.Point(328, 31);
            this.lbOBApelido.Name = "lbOBApelido";
            this.lbOBApelido.Size = new System.Drawing.Size(13, 17);
            this.lbOBApelido.TabIndex = 1608;
            this.lbOBApelido.Text = "*";
            // 
            // lbApelido
            // 
            this.lbApelido.AutoSize = true;
            this.lbApelido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbApelido.ForeColor = System.Drawing.Color.Black;
            this.lbApelido.Location = new System.Drawing.Point(341, 31);
            this.lbApelido.Name = "lbApelido";
            this.lbApelido.Size = new System.Drawing.Size(55, 17);
            this.lbApelido.TabIndex = 1607;
            this.lbApelido.Text = "Apelido";
            // 
            // txtApelido
            // 
            this.txtApelido.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApelido.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApelido.Location = new System.Drawing.Point(344, 49);
            this.txtApelido.Margin = new System.Windows.Forms.Padding(4);
            this.txtApelido.MaxLength = 50;
            this.txtApelido.Name = "txtApelido";
            this.txtApelido.Size = new System.Drawing.Size(156, 27);
            this.txtApelido.TabIndex = 1602;
            // 
            // lbCliente
            // 
            this.lbCliente.AutoSize = true;
            this.lbCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCliente.ForeColor = System.Drawing.Color.Black;
            this.lbCliente.Location = new System.Drawing.Point(36, 31);
            this.lbCliente.Name = "lbCliente";
            this.lbCliente.Size = new System.Drawing.Size(51, 17);
            this.lbCliente.TabIndex = 1604;
            this.lbCliente.Text = "Cliente";
            // 
            // txtNome
            // 
            this.txtNome.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(39, 49);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4);
            this.txtNome.MaxLength = 50;
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(297, 27);
            this.txtNome.TabIndex = 1601;
            // 
            // lblrg
            // 
            this.lblrg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblrg.AutoSize = true;
            this.lblrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblrg.Location = new System.Drawing.Point(371, 136);
            this.lblrg.Name = "lblrg";
            this.lblrg.Size = new System.Drawing.Size(13, 17);
            this.lblrg.TabIndex = 1621;
            this.lblrg.Text = "*";
            // 
            // lblCpf
            // 
            this.lblCpf.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCpf.AutoSize = true;
            this.lblCpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCpf.Location = new System.Drawing.Point(259, 136);
            this.lblCpf.Name = "lblCpf";
            this.lblCpf.Size = new System.Drawing.Size(13, 17);
            this.lblCpf.TabIndex = 1620;
            this.lblCpf.Text = "*";
            // 
            // lbRG
            // 
            this.lbRG.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbRG.AutoSize = true;
            this.lbRG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRG.ForeColor = System.Drawing.Color.Black;
            this.lbRG.Location = new System.Drawing.Point(388, 135);
            this.lbRG.Name = "lbRG";
            this.lbRG.Size = new System.Drawing.Size(29, 17);
            this.lbRG.TabIndex = 1619;
            this.lbRG.Text = "RG";
            // 
            // lbCpfOuCnpj
            // 
            this.lbCpfOuCnpj.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbCpfOuCnpj.AutoSize = true;
            this.lbCpfOuCnpj.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCpfOuCnpj.ForeColor = System.Drawing.Color.Black;
            this.lbCpfOuCnpj.Location = new System.Drawing.Point(272, 135);
            this.lbCpfOuCnpj.Name = "lbCpfOuCnpj";
            this.lbCpfOuCnpj.Size = new System.Drawing.Size(81, 17);
            this.lbCpfOuCnpj.TabIndex = 1618;
            this.lbCpfOuCnpj.Text = "CPF / CNPJ";
            // 
            // txtCPFouCNPJ
            // 
            this.txtCPFouCNPJ.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCPFouCNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCPFouCNPJ.Location = new System.Drawing.Point(274, 154);
            this.txtCPFouCNPJ.Margin = new System.Windows.Forms.Padding(4);
            this.txtCPFouCNPJ.MaxLength = 20;
            this.txtCPFouCNPJ.Name = "txtCPFouCNPJ";
            this.txtCPFouCNPJ.Size = new System.Drawing.Size(109, 27);
            this.txtCPFouCNPJ.TabIndex = 1612;
            // 
            // lbOBEmail
            // 
            this.lbOBEmail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbOBEmail.AutoSize = true;
            this.lbOBEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOBEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbOBEmail.Location = new System.Drawing.Point(24, 81);
            this.lbOBEmail.Name = "lbOBEmail";
            this.lbOBEmail.Size = new System.Drawing.Size(13, 17);
            this.lbOBEmail.TabIndex = 1617;
            this.lbOBEmail.Text = "*";
            // 
            // txtEmail
            // 
            this.txtEmail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(40, 102);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.MaxLength = 200;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(258, 27);
            this.txtEmail.TabIndex = 1609;
            // 
            // txtCelular
            // 
            this.txtCelular.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCelular.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCelular.Location = new System.Drawing.Point(39, 154);
            this.txtCelular.Margin = new System.Windows.Forms.Padding(4);
            this.txtCelular.MaxLength = 15;
            this.txtCelular.Name = "txtCelular";
            this.txtCelular.Size = new System.Drawing.Size(227, 27);
            this.txtCelular.TabIndex = 1611;
            // 
            // lbCelular
            // 
            this.lbCelular.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbCelular.AutoSize = true;
            this.lbCelular.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCelular.ForeColor = System.Drawing.Color.Black;
            this.lbCelular.Location = new System.Drawing.Point(37, 133);
            this.lbCelular.Name = "lbCelular";
            this.lbCelular.Size = new System.Drawing.Size(52, 17);
            this.lbCelular.TabIndex = 1616;
            this.lbCelular.Text = "Celular";
            // 
            // lbTelefone
            // 
            this.lbTelefone.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbTelefone.AutoSize = true;
            this.lbTelefone.BackColor = System.Drawing.Color.Transparent;
            this.lbTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTelefone.ForeColor = System.Drawing.Color.Black;
            this.lbTelefone.Location = new System.Drawing.Point(306, 81);
            this.lbTelefone.Name = "lbTelefone";
            this.lbTelefone.Size = new System.Drawing.Size(64, 17);
            this.lbTelefone.TabIndex = 1615;
            this.lbTelefone.Text = "Telefone";
            // 
            // txtTelefone
            // 
            this.txtTelefone.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefone.Location = new System.Drawing.Point(309, 102);
            this.txtTelefone.Margin = new System.Windows.Forms.Padding(4);
            this.txtTelefone.MaxLength = 15;
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(191, 27);
            this.txtTelefone.TabIndex = 1610;
            // 
            // lbEmail
            // 
            this.lbEmail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbEmail.AutoSize = true;
            this.lbEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEmail.ForeColor = System.Drawing.Color.Black;
            this.lbEmail.Location = new System.Drawing.Point(36, 81);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(47, 17);
            this.lbEmail.TabIndex = 1614;
            this.lbEmail.Text = "E-mail";
            // 
            // txtRG
            // 
            this.txtRG.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRG.Location = new System.Drawing.Point(391, 154);
            this.txtRG.Margin = new System.Windows.Forms.Padding(4);
            this.txtRG.MaxLength = 20;
            this.txtRG.Name = "txtRG";
            this.txtRG.Size = new System.Drawing.Size(109, 27);
            this.txtRG.TabIndex = 1613;
            // 
            // Pessoa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.lbCliente);
            this.Controls.Add(this.lblrg);
            this.Controls.Add(this.lblCpf);
            this.Controls.Add(this.lbRG);
            this.Controls.Add(this.lbCpfOuCnpj);
            this.Controls.Add(this.txtCPFouCNPJ);
            this.Controls.Add(this.lbOBEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtCelular);
            this.Controls.Add(this.lbCelular);
            this.Controls.Add(this.lbTelefone);
            this.Controls.Add(this.txtTelefone);
            this.Controls.Add(this.lbEmail);
            this.Controls.Add(this.txtRG);
            this.Controls.Add(this.lbOBCliente);
            this.Controls.Add(this.lbOBApelido);
            this.Controls.Add(this.lbApelido);
            this.Controls.Add(this.txtApelido);
            this.Controls.Add(this.txtNome);
            this.Name = "Pessoa";
            this.Text = "Cadastro de Pessoa";
            this.Controls.SetChildIndex(this.txtNome, 0);
            this.Controls.SetChildIndex(this.txtApelido, 0);
            this.Controls.SetChildIndex(this.lbApelido, 0);
            this.Controls.SetChildIndex(this.lbOBApelido, 0);
            this.Controls.SetChildIndex(this.lbOBCliente, 0);
            this.Controls.SetChildIndex(this.txtRG, 0);
            this.Controls.SetChildIndex(this.lbEmail, 0);
            this.Controls.SetChildIndex(this.txtTelefone, 0);
            this.Controls.SetChildIndex(this.lbTelefone, 0);
            this.Controls.SetChildIndex(this.lbCelular, 0);
            this.Controls.SetChildIndex(this.txtCelular, 0);
            this.Controls.SetChildIndex(this.txtEmail, 0);
            this.Controls.SetChildIndex(this.lbOBEmail, 0);
            this.Controls.SetChildIndex(this.txtCPFouCNPJ, 0);
            this.Controls.SetChildIndex(this.lbCpfOuCnpj, 0);
            this.Controls.SetChildIndex(this.lbRG, 0);
            this.Controls.SetChildIndex(this.lblCpf, 0);
            this.Controls.SetChildIndex(this.lblrg, 0);
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.lbCliente, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.Label lbOBCliente;
        protected System.Windows.Forms.Label lbOBApelido;
        protected System.Windows.Forms.Label lbApelido;
        protected System.Windows.Forms.TextBox txtApelido;
        protected System.Windows.Forms.Label lbCliente;
        protected System.Windows.Forms.TextBox txtNome;
        protected System.Windows.Forms.Label lblrg;
        protected System.Windows.Forms.Label lblCpf;
        protected System.Windows.Forms.Label lbRG;
        protected System.Windows.Forms.Label lbCpfOuCnpj;
        protected System.Windows.Forms.TextBox txtCPFouCNPJ;
        protected System.Windows.Forms.Label lbOBEmail;
        protected System.Windows.Forms.TextBox txtEmail;
        protected System.Windows.Forms.TextBox txtCelular;
        protected System.Windows.Forms.Label lbCelular;
        protected System.Windows.Forms.Label lbTelefone;
        protected System.Windows.Forms.TextBox txtTelefone;
        protected System.Windows.Forms.Label lbEmail;
        protected System.Windows.Forms.TextBox txtRG;
    }
}
